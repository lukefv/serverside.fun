-- AlterTable
ALTER TABLE "SnitchLogs" ADD COLUMN     "ip" TEXT NOT NULL DEFAULT E'';
