-- AlterTable
ALTER TABLE "Games" ADD COLUMN     "description" TEXT NOT NULL DEFAULT E'';
