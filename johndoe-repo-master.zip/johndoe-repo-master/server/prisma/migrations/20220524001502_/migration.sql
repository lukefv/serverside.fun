-- AlterTable
ALTER TABLE "Activity" ADD COLUMN     "action" TEXT;
