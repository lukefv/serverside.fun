-- DropIndex
DROP INDEX "Buyers_purchaseIdentifier_key";
