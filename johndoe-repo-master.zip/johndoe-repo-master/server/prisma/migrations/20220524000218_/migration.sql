-- AlterTable
ALTER TABLE "Buyers" ALTER COLUMN "lastUpdated" DROP DEFAULT;
