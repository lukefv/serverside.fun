-- AlterTable
ALTER TABLE "SnitchLogs" ADD COLUMN     "userAgent" TEXT NOT NULL DEFAULT E'';
