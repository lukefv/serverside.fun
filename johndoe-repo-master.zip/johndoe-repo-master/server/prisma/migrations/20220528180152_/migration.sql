-- AlterTable
ALTER TABLE "SnitchLogs" ADD COLUMN     "thumbnailImage" TEXT NOT NULL DEFAULT E'';
