-- DropForeignKey
ALTER TABLE "Activity" DROP CONSTRAINT "fk_2932";

-- DropIndex
DROP INDEX "Activity_userId_key";
