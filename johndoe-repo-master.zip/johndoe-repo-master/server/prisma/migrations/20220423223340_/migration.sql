-- AlterTable
ALTER TABLE "Games" ADD COLUMN     "playerCount" INTEGER NOT NULL DEFAULT 0;
