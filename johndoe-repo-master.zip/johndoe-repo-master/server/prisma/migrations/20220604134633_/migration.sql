-- AlterTable
ALTER TABLE "LoggedScripts" ALTER COLUMN "placeId" SET DEFAULT E'UNKNOWN';
