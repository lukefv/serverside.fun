/*
  Warnings:

  - You are about to drop the column `expires` on the `Buyers` table. All the data in the column will be lost.

*/
-- AlterTable
ALTER TABLE "Buyers" DROP COLUMN "expires";
