-- AlterTable
ALTER TABLE "LoggedScripts" ADD COLUMN     "robloxUsername" TEXT NOT NULL DEFAULT E'';
