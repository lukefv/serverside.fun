-- AlterTable
ALTER TABLE "LoggedScripts" ADD COLUMN     "userId" INTEGER NOT NULL DEFAULT 0;
