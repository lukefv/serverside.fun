-- RenameForeignKey
ALTER TABLE "Buyers" RENAME CONSTRAINT "fk_15" TO "fk_27";
