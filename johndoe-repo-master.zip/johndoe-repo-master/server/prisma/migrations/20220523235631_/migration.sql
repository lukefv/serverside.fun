-- AlterTable
ALTER TABLE "Buyers" ALTER COLUMN "lastUpdated" DROP NOT NULL,
ALTER COLUMN "lastUpdated" DROP DEFAULT;
