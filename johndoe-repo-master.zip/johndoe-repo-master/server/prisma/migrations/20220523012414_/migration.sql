-- AlterTable
ALTER TABLE "PrivateScripts" ALTER COLUMN "posterId" SET DATA TYPE TEXT;
