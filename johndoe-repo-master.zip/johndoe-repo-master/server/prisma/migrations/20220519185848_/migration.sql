-- AlterTable
ALTER TABLE "PrivateScripts" ADD COLUMN     "description" TEXT NOT NULL DEFAULT E'';

-- AlterTable
ALTER TABLE "PublicScripts" ADD COLUMN     "description" TEXT NOT NULL DEFAULT E'';
