-- AlterTable
ALTER TABLE "Activity" ALTER COLUMN "ipAddress" DROP NOT NULL;
