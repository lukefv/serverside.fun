-- AlterTable
ALTER TABLE "Buyers" ALTER COLUMN "robloxId" DROP NOT NULL;
